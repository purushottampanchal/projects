﻿namespace WebApi1.Model
{
    public class Movie
    {
        public int? id { get; set; }
        public string? Name { get; set; }
    }
}
